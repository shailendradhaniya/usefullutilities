package com.visa.demos.walletapp.util;

import android.content.Context;
import com.google.gson.Gson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;

import static com.visa.demos.walletapp.util.EncryptionUtility.CEK_SIZE_BYTES;
import static com.visa.demos.walletapp.util.EncryptionUtility.IV_SIZE_BYTES;
import static com.visa.demos.walletapp.util.EncryptionUtility.bs64Decode;
import static com.visa.demos.walletapp.util.EncryptionUtility.bs64Encode;
import static com.visa.demos.walletapp.util.EncryptionUtility.encryptData;
import static com.visa.demos.walletapp.util.EncryptionUtility.generateKey;
import static com.visa.demos.walletapp.util.EncryptionUtility.generateSalt;
import static com.visa.demos.walletapp.util.EncryptionUtility.utf8;

// TODO: Auto-generated Javadoc
/**
 * *** Note: This is not encryption framework related code. For lack of better place/artifact, it's placed inside encryption
 * project, so client applications will get it easily. At this point, creating a new artifact for single utility class is not justified.
 *
 * A Simple utility to parse and generate Java Web Token (JWT). This utility provides simple methods to create a token string
 * when a kid, claim and shared secrete is given. It only supports a bare-minimum set of options from JWT spec.
 *
 * @author : pmungse
 * Date    : 8/11/14
 * @since  : 2.0.6
 */
public final class JWTLocalUtility {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(JWTLocalUtility.class) ;

  /**
   * Returns the JWE compact serialization formatted JWT for the given claim (plaintext) information using the given kid and
   * shared secret. It will do the encryption of claim (assertion) and convert all data into base64-url-safe encoding and return
   * the JWE compact serialization format, as:
   * BASE64URL(UTF8(JWE Protected Header)) + "." + BASE64URL(JWE Encrypted Key - CEK) + "." + BASE64URL(JWE Initialization Vector)
   * + "." + BASE64URL(JWE Ciphertext) + "." + BASE64URL(JWE Authentication Tag)
   *
   * @param context the context
   * @param plainText the plain text
   * @param kid the kid
   * @return Base64 encoded JWE
   */
  public static final String createJwe(Context context,byte[] plainText, String kid) {
    LOG.trace("Creating JWE using kid: {}", kid) ;
    String jwe = null ;
    try {
      // create salt
      byte[] dataSalt = generateSalt(IV_SIZE_BYTES);
      byte[] rsk  =  generateKey(CEK_SIZE_BYTES) ;

      // wrap/encrypt key
      byte[] ersk = EncryptionUtility.encryptRandomWithIBK(context, rsk);
      byte[] headerBytes = buildJweHeaderBytes(kid);

      // encrypt data using key
      //byte[] dataSalt = generateSalt(IV_SIZE_BYTES) ;
      EncryptionUtility.CipherTextData encryptedData = encryptData(rsk, dataSalt, plainText,  headerBytes ) ;

      // combine all together in return string
      jwe = buildJwe(headerBytes, ersk, dataSalt, encryptedData) ;
      LOG.trace("The JWE created : {}" , jwe) ;

    } catch(Exception e) {
      LOG.error("Error in creating JWE", e);
    }

    return jwe ;
  }

  /**
   * Parses the given encrypted & encoded JWE into it's subparts. Also converts the encoded header into json structure to
   * access sub elements in it.
   *
   * @param encyptedJwe the encypted jwe
   * @return the JWE data
   */
  public static final JWEData parseJwe(String encyptedJwe) {
    return new JWEData(encyptedJwe) ;
  }

  /**
   * Returns the api-key / kid from the encrypted JWE. This will parse the header from JWE and get kid information. It is
   * required for the clients to fetch the shared secret.
   *
   * @param encryptedJwe the encrypted jwe
   * @return the kid from jwe
   */
  public static final String getKidFromJwe(String encryptedJwe) {
    JWEData jwe = parseJwe(encryptedJwe) ;
    return jwe.getHeader().getKid() ;
  }


  /**
   * Returns the decrypted data from JWE using the given secret and CEK in JWE.
   *
   * @param context the context
   * @param jwe the jwe
   * @param keyId the key id
   * @return the string
   */
  public static final String decryptJwe(Context context,JWEData jwe, int keyId) {

    // get header
    // get key salt, encrypted key
    // decrypt key

    byte[] ersk = bs64Decode(jwe.ersk);
    byte[] rskBytes = EncryptionUtility.decryptRandomWithIBK(context,ersk, keyId);

    // decode data salt & tag
    // decrypt data
    byte[] data = EncryptionUtility.decryptData(rskBytes, bs64Decode(jwe.getDataSalt()), bs64Decode(jwe.getCipherText()),
            bs64Decode(jwe.getDataAuthTag()), null) ;

      //Extracting the plain text leaving behind the first byte, which is tag value
      byte[] sensitiveData = Arrays.copyOfRange(data, 1, data.length) ;

      // get plain text from the sensitiveData bytes using UTF-8 charset
      try {
          String plainText =  new String(sensitiveData, "UTF-8") ;
      } catch (UnsupportedEncodingException e) {
          e.printStackTrace();
      }

      return new String(data, utf8) ;
  }

  /**
   * Returns the string information in the claim-set of JWE. This could be either for JWT or PAN encryption. It deconstructs the parts
   * of JWE and decrypts the payload using given shared secret. This implements only subset of JWE functionality (i.e algo=dir)
   *
   * @param header the header
   * @return JSON String represented in the claim.
   */
//  public static final String decryptJwe(String encryptedJwe, String secret) {
//
//    return decryptJwe(new JWEData(encryptedJwe), secret) ;
//  }


  /**
   * Create the json format from given JWE header object.
   * @param header
   * @return
   */
  private static String getJson(JWEHeader header) {
    String json ;
    try {
      json = new Gson().toJson(header);
      LOG.trace("JSON Created from header object: {}", json) ;
    }catch(Exception e) {
      LOG.error("Error in creating json for JWT header", e) ;
      throw new RuntimeException(e) ;
    }
    return json ;

  }


  /**
   * Builds the jwe header bytes.
   *
   * @param kid the kid
   * @return the byte[]
   */
  private static byte[] buildJweHeaderBytes(String kid) {
    // create jwe header
    JWEHeader header = new JWEHeader() ;
    header.setKid(kid) ;

    String headerJson = getJson(header) ;
    LOG.trace("headerJson: {}", headerJson) ;
    return headerJson.getBytes(utf8);
  }

  /**
   * Builds the jwe.
   *
   * @param header the header
   * @param ersk the ersk
   * @param dataSalt the data salt
   * @param encryptedData the encrypted data
   * @return the string
   */
  private static String buildJwe(byte[] header, byte[] ersk, byte[] dataSalt, EncryptionUtility.CipherTextData encryptedData) {
    StringBuilder jwe = new StringBuilder() ;

    jwe.append(bs64Encode(header) )
        .append(".")
        .append(bs64Encode(ersk))
        .append(".")
        .append(bs64Encode(dataSalt))
        .append(".")
        .append(encryptedData.getCipherText())
        .append(".")
        .append(encryptedData.getAuthTag()) ;

    LOG.trace("The created JWE: {}" , jwe.toString() );

    return jwe.toString();
  }


  /**
   * Class to hold the JWE header information. It defaults the key encryption and data encryption to AES/GCM/256 bit key.
   * the JWE Type is default to 'JOSE'. Rest information is taken from the actual jwt.
   */
  public static class JWEHeader {
    
    /** The alg. */
    private String alg = "RSA1_5" ;
    
    /** The enc. */
    private String enc = "AGCM256" ;
    
    /** The typ. */
    private String typ = "JOSE" ;
    
    /** The kid. */
    private String kid = "1234";
    
    /** The channel security context. */
    private String channelSecurityContext = "RSA_PKI";
    
    /** The iat. */
    private String iat =  ""+System.currentTimeMillis();

    /**
     * Instantiates a new JWE header.
     */
    public JWEHeader() { }

    /**
     * Gets the alg.
     *
     * @return the alg
     */
    public String getAlg() { return  alg ;}
    
    /**
     * Gets the channel security context.
     *
     * @return the channel security context
     */
    public String getChannelSecurityContext() { return  channelSecurityContext ;}
    
    /**
     * Gets the enc.
     *
     * @return the enc
     */
    public String getEnc(){ return  enc ;}
    
    /**
     * Gets the typ.
     *
     * @return the typ
     */
    public String getTyp(){ return typ ;}
    
    /**
     * Gets the kid.
     *
     * @return the kid
     */
    public String getKid(){ return kid ;  }
    
    /**
     * Gets the iat.
     *
     * @return the iat
     */
    public String getIat(){ return iat ;  }

      /**
       * Sets the kid.
       *
       * @param kid the new kid
       */
      public void setKid(String kid) {
          this.kid = kid;
      }

  }


  /**
   * Class to hold the encoded & encrypted JWE data. It parses the JWE assuming it's compact serialization and breaks
   * it into 5 parts : header, encrypted key, salt, encrypted payload and authentication tag. Header is further decoded
   * into JWEHeader as per above class.
   *
   *  **NOTE** Any header elements not given in JWEHeader will be ignored - potentially failing auth tag check.
   */
  public static class JWEData {
    
    /** The header json. */
    private String headerJson ;
    
    /** The header. */
    private JWEHeader header ;
    
    /** The ersk. */
    private String ersk ;
    
    /** The data salt. */
    private String dataSalt ;
    
    /** The cipher text. */
    private String cipherText ;
    
    /** The data auth tag. */
    private String dataAuthTag ;

    /**
     * Instantiates a new JWE data.
     *
     * @param encryptedJwe the encrypted jwe
     */
    public JWEData(String encryptedJwe) {
      assert encryptedJwe != null ;
      try {
        String[] parts = encryptedJwe.split("\\.", -1);
        ersk = parts[1];
        dataSalt = parts[2];
        cipherText = parts[3];
        dataAuthTag = parts[4];
        String headerEncoded = parts[0];
        byte[] hdBytes = bs64Decode(headerEncoded);
        headerJson = new String(hdBytes, utf8) ;
          Gson gson = new Gson();

          try {
              header = gson.fromJson(headerJson, JWEHeader.class);
          } catch (Exception e) {
              e.printStackTrace();
          }
      }catch(Exception e) {
        LOG.error("Error in parsing jwe into sub-parts, jwe:" + encryptedJwe, e);
        throw new RuntimeException(e) ;
      }
    }

    /**
     * Gets the header.
     *
     * @return the header
     */
    public JWEHeader getHeader() { return header ;}
    
    /**
     * Gets the header json.
     *
     * @return the header json
     */
    public String getHeaderJson() { return headerJson ; }
    
    /**
     * Gets the ersk.
     *
     * @return the ersk
     */
    public String getErsk() { return ersk; }
    
    /**
     * Gets the data salt.
     *
     * @return the data salt
     */
    public String getDataSalt() { return dataSalt; }
    
    /**
     * Gets the cipher text.
     *
     * @return the cipher text
     */
    public String getCipherText() { return cipherText; }
    
    /**
     * Gets the data auth tag.
     *
     * @return the data auth tag
     */
    public String getDataAuthTag() { return dataAuthTag; }

  }

}
