import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.security.KeyPair;
import java.security.cert.Certificate;
import java.util.Properties;
import java.util.UUID;

import org.apache.log4j.Logger;

import ca.ugo.mobilewallet.token.encryptionutil.EncryptionUtil;
import ca.ugo.mobilewallet.token.encryptionutil.JWTUtil;
import ca.ugo.mobilewallet.token.encryptionutil.JWTUtil.JWSData;


public class TestJWT {

	public static String keystore_provider;

	public static String slotPassword;

	public static String keystore_type;

	static Logger log = Logger.getLogger("TestJWT");
	private static final Charset UTF8 = Charset.forName("UTF-8");

	public static String clientID;

	//HSM label for TEPK
	//FOR TESTING ONLY, using existing key, DO NOT OVERWRITE
	public static String TEPK_LABEL;

	public static String API_KEY;

	//TEST ONLY
	public static String sharedSecret;

	//TRUE = all BouncyCastle (for local testing)
	//FALSE = use HSM
	private static boolean DEBUG = false;

	public static void main(String[] args) {
		try{

			init();

			if(DEBUG){
				keystore_provider = "BC";
				slotPassword = null;
				keystore_type = null;
			}
			JWTUtil jwtUtil = new JWTUtil(keystore_provider, slotPassword, keystore_type, TEPK_LABEL, DEBUG);


			//
			//DSK
			//

			//Generate DSK
			byte[] dsk = jwtUtil.generateDSK();

			//create JWE for DSK
			String dskJWE = jwtUtil.createJweKey( dsk, clientID);

			String decryptedJwe;
			if(DEBUG){
				//TEST - decrypt
				decryptedJwe = jwtUtil.decryptJweKey( dskJWE);
				log.info("Decrypted: "+ new String(decryptedJwe));
			}
			log.info("\n\n");

			//
			//Exponents, certificates
			//

			//get a keys and certificates
			KeyPair keyPair = jwtUtil.generateKeyPair();
			Certificate signingCertificate = null;
			if(DEBUG){
				signingCertificate = jwtUtil.getSigningCertificate(keyPair);
				log.info("Created cert of type: " + signingCertificate.getType());
			} else {
				signingCertificate = jwtUtil.getCertificateByName("UGO_WCAP_EXPORT_PUBLIC_CERT_2014");
				log.info("Cert of type: " + signingCertificate.getType());
			}

			//create private exponent
			String privateExponent = jwtUtil.getPrivateKeyExponent(keyPair.getPrivate());
			log.info("Private exponent: " + privateExponent);
			byte[] pE = privateExponent.getBytes(UTF8);

			//create JWE for private exponent
			String peJWE = jwtUtil.createJweKey( pE, dsk, clientID);

			if(DEBUG){
				//TEST - decrypt
				decryptedJwe = jwtUtil.decryptJweKey( peJWE);
				log.info("Decrypted: "+ new String(decryptedJwe));
			}
			log.info("\n\n");

			//CONVERT CERTIFICATE TO PEM
			//String pem = JWTUtil.toPEM(signingCertificate);
			String pem = JWTUtil.toPEM(signingCertificate);
			log.info("PEM: "+ pem);


			///
			///JWS
			///
			String jti = UUID.randomUUID().toString();
			String assertion = "/sdk/*";
			String jws = jwtUtil.createAssertion( API_KEY, jti, assertion, sharedSecret);

			log.info("Assertion: "+ jws);

			log.info("HEADER OUT: "+ new String(EncryptionUtil.base64Decode((new JWSData(jws)).getHeaderJsonEncoded()), UTF8));

			//TEST KRISHNA - extract certificate
			/*
			String[] certNames = {"PCB_RK_CC_ISS_PUB_2014",
					"UGO_WCAP_ROOTSEENC_KEY_2014",
					"TDB_PUBLICKEY_PIN_2014",
					"TDB_PUBLICKEY_PAN_2014",
					"TDB_PUBLICKEY_CVV2_2014",
					"UGO_WCAP_BASEROOT_KEY_2014",
					"UGO_WCAP_EXPORT_PUBLIC_CERT_2014",
					"Peters_Test_Public_derived",
					"UGO_WALLET_PKI_DOMAIN_PUBLIC_2014",
					"UGO_WALLET_PKI_DOMAIN_2014",
					"UGO_WALLET_DOMAIN_MASTER_KEY_2014",
					"UGO_WCAP_MASTERROOT_KEY_2014"
			};

			for(String certName : certNames){
				Certificate testCert;
				try {
					System.out.println(certName);
					testCert = jwtUtil.getTestCertificate(certName);
					System.out.println("CERT: "+ testCert.toString());
				} catch (Exception ex){
					//ignore
				}
			}
			 */

			log.info("Done");

		} catch(Exception ex){
			System.out.println("Error: "+ ex.getMessage());
			ex.printStackTrace();
		}
	}

	private static void init(){
		Properties prop = new Properties();
		InputStream input = null;

		try {

			String filename = "config.properties";
			input = TestJWT.class.getClassLoader().getResourceAsStream(filename);
			if(input==null){
				System.out.println("Sorry, unable to find " + filename);
				return;
			}

			//load a properties file from class path, inside static method
			prop.load(input);

			//get the property value and print it out
			keystore_provider = prop.getProperty("keystore_provider");
			slotPassword = prop.getProperty("slotPassword");
			keystore_type = prop.getProperty("keystore_type");

			clientID = prop.getProperty("CLIENT_ID");
			TEPK_LABEL = prop.getProperty("TEPK_LABEL");
			API_KEY = prop.getProperty("API_KEY");
			sharedSecret = prop.getProperty("SHARED_SECRET");

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally{
			if(input!=null){
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}
}
