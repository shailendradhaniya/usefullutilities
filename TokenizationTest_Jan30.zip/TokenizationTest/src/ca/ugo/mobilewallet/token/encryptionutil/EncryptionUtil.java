package ca.ugo.mobilewallet.token.encryptionutil;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPrivateKeySpec;
import java.util.Arrays;
import java.util.Date;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.ShortBufferException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.log4j.Logger;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.cert.X509v3CertificateBuilder;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.engines.AESFastEngine;
import org.bouncycastle.crypto.modes.GCMBlockCipher;
import org.bouncycastle.crypto.params.AEADParameters;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.jcajce.provider.asymmetric.x509.CertificateFactory;
import org.bouncycastle.openssl.jcajce.JcaPEMWriter;
import org.bouncycastle.operator.ContentSigner;

import au.com.safenet.crypto.WrappingKeyStore;
import au.com.safenet.crypto.provider.RSAPubKey;


/**
 * The Class EncryptionUtil.
 */
public final class EncryptionUtil {

	static Logger log = Logger.getLogger("EncryptionUtil");
	private static final Charset UTF8 = Charset.forName("UTF-8");

	public static final int RSA_KEY_SIZE_BITS    = 2048 ;
	public static final int RSA_KEY_SIZE_BYTES   = RSA_KEY_SIZE_BITS / 8 ;

	public static final int CEK_SIZE_BITS        = 128 ;
	public static final int CEK_SIZE_BYTES       = CEK_SIZE_BITS / 8 ;

	public static final int AUTH_TAG_SIZE_BITS   = 128 ;
	public static final int AUTH_TAG_SIZE_BYTES  = AUTH_TAG_SIZE_BITS / 8 ;

	public static final int IV_SIZE_BITS         = 96 ;
	public static final int IV_SIZE_BYTES        = IV_SIZE_BITS / 8 ;

	/** The signing algorithm. */
	public static final String SIGN_ALGORITHM    = "HmacSHA256";

	protected static final boolean ENCRYPT_MODE     = true ;
	protected static final boolean DECRYPT_MODE     = false ;

	//in DEBUG mode use BC instead of HSM
	//for local testing
	protected boolean DEBUG = false ;


	/** The keystore provider (from config). */
	private String keystore_provider = null;

	/** The bouncycastle provider. */
	private final String bouncycastle_provider = "BC";

	/** The key store. */
	private WrappingKeyStore keyStore = null;

	//TESTING ONLY
	KeyPair rsaPair;


	/**
	 * Instantiates a new encryption util.
	 *
	 * @param keystore_provider the keystore_provider
	 * @param slotPassword the slot password
	 * @param keystore_type the keystore_type
	 * @param debug the debug
	 * @throws KeyStoreException
	 * @throws NoSuchProviderException
	 * @throws NoSuchAlgorithmException
	 * @throws CertificateException
	 * @throws IOException
	 * @throws InvalidKeyException
	 * @throws NoSuchPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 * @throws UnrecoverableKeyException
	 */
	public EncryptionUtil(String keystore_provider, String slotPassword, String keystore_type, boolean debug) throws KeyStoreException, NoSuchProviderException, NoSuchAlgorithmException, CertificateException, IOException, InvalidKeyException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, UnrecoverableKeyException{
		this.keystore_provider = keystore_provider;
		this.DEBUG = debug;

		//provided for HSM
		if(slotPassword != null && !DEBUG){
			keyStore = WrappingKeyStore.getInstance (keystore_type, keystore_provider);
			keyStore.load(null, slotPassword.toCharArray());
		}
		if(DEBUG)
			//key pair used to test enc/dec
			//normally we get public key from VISA, and do not have their private key
			rsaPair = this.createKeyPair();
	}

	/**
	 * Instantiates a new encryption util.
	 *
	 * @param keystore_provider the keystore_provider
	 * @param slotPassword the slot password
	 * @param keystore_type the keystore_type
	 * @throws KeyStoreException
	 * @throws NoSuchProviderException
	 * @throws NoSuchAlgorithmException
	 * @throws CertificateException
	 * @throws IOException
	 * @throws InvalidKeyException
	 * @throws NoSuchPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 * @throws UnrecoverableKeyException
	 */
	public EncryptionUtil(String keystore_provider, String slotPassword, String keystore_type) throws KeyStoreException, NoSuchProviderException, NoSuchAlgorithmException, CertificateException, IOException, InvalidKeyException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, UnrecoverableKeyException{
		this( keystore_provider, slotPassword, keystore_type, false);
	}


	/**
	 * Create private/public key pair
	 * Generate outside of the HSM, otherwise we can not extract exponent
	 *
	 * @return the key pair
	 * @throws InvalidKeyException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchProviderException
	 * @throws NoSuchPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 * @throws KeyStoreException
	 * @throws UnrecoverableKeyException
	 */
	public KeyPair createKeyPair() throws InvalidKeyException, NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, KeyStoreException, UnrecoverableKeyException{
		KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA", bouncycastle_provider);
		keyGen.initialize(RSA_KEY_SIZE_BITS);
		return keyGen.generateKeyPair();
	}

	/**
	 * Gets the private key exponent.
	 *
	 * @param privateKey the private key
	 * @return the private key exponent
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeySpecException
	 * @throws NoSuchProviderException
	 */
	public String getPrivateKeyExponent(PrivateKey privateKey) throws NoSuchAlgorithmException, InvalidKeySpecException, NoSuchProviderException{
		KeyFactory keyFac = KeyFactory.getInstance("RSA", bouncycastle_provider);
		RSAPrivateKeySpec pkSpec = (RSAPrivateKeySpec)keyFac.getKeySpec(privateKey, RSAPrivateKeySpec.class);
		BigInteger issuerEncPrivateKeyExponent = pkSpec.getPrivateExponent();
		String exponentString = issuerEncPrivateKeyExponent.toString(16);

		return exponentString;
	}

	/**
	 * Gets the signing certificate.
	 * LOCAL TEST ONLY - certs should come from HSM
	 *
	 * @param keyPair the key pair
	 * @return the signing certificate
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeySpecException
	 * @throws CertificateException
	 * @throws IOException
	 */
	public Certificate getSigningCertificate(KeyPair keyPair) throws NoSuchAlgorithmException, InvalidKeySpecException, CertificateException, IOException{
		return generateSigningCertificate(keyPair);
	}

	/**
	 * Extract certificate by name.
	 *
	 * @param certName the cert name
	 * @return the certificate by name
	 * @throws KeyStoreException
	 */
	public Certificate getCertificateByName(String certName) throws KeyStoreException{
		return keyStore.getCertificate(certName);
	}

	/**
	 * Convert certificate to pem.
	 *
	 * @param cert
	 * @return pem string
	 * @throws IOException
	 */
	public static String toPEM(Certificate cert) throws IOException {
		StringWriter sw = new StringWriter();
		JcaPEMWriter pemWriter = new JcaPEMWriter(sw);
		pemWriter.writeObject(cert);
		pemWriter.close();
		return sw.toString();
	}


	///
	///SIGNING
	/**
	 * Compute hmac sh a256.
	 *
	 * @param key the key
	 * @param stringToSign the string to sign
	 * @return the string
	 * @throws InvalidKeyException
	 * @throws NoSuchAlgorithmException
	 */
	//
	public String computeHmacSHA256(String key, String stringToSign) throws InvalidKeyException, NoSuchAlgorithmException{
		Mac sha256_HMAC = Mac.getInstance(SIGN_ALGORITHM);
		SecretKeySpec secret_key = new SecretKeySpec(key.getBytes(UTF8), SIGN_ALGORITHM);
		sha256_HMAC.init(secret_key);
		byte [] signature = sha256_HMAC.doFinal(stringToSign.getBytes(UTF8));

		return new String(urlSafeBase64Encode(signature));
	}



	/**
	 * Generate signing certificate.
	 * LOCAL TEST ONLY - certs should come from HSM
	 *
	 * @param keyPair the key pair
	 * @return the x509 certificate
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeySpecException
	 * @throws IOException
	 * @throws CertificateException
	 */
	public X509Certificate generateSigningCertificate(KeyPair keyPair) throws NoSuchAlgorithmException, InvalidKeySpecException, IOException, CertificateException{

		Date startDate = new Date(System.currentTimeMillis() - 10000);
		Date expiryDate = new Date(System.currentTimeMillis() + 24L * 3600 * 1000);

		X509v3CertificateBuilder certBuilder = new X509v3CertificateBuilder(new X500Name("CN= UGO TEST"), BigInteger.valueOf(new SecureRandom().nextLong()), startDate, expiryDate, new X500Name("CN= UGO TEST"), SubjectPublicKeyInfo.getInstance(keyPair.getPublic().getEncoded()));
		byte[] certBytes = certBuilder.build(new JCESigner(keyPair.getPrivate(), "SHA256withRSA")).getEncoded();
		CertificateFactory certificateFactory = new CertificateFactory();
		X509Certificate certificate = (X509Certificate)certificateFactory.engineGenerateCertificate(new ByteArrayInputStream(certBytes));

		return certificate;
	}

	//  TEPK START.
	/**
	 * Store key in HSM
	 * 
	 * @param tepk the tepk
	 * @param tepkLabel the tepk label
	 * @throws KeyStoreException
	 */
	public void storeTEPK( RSAPubKey tepk, String tepkLabel) throws KeyStoreException
	{
		//DO NOT SAVE KEY, this overwrites
		//keyStore.setKeyEntry( tepkLabel, tepk, null, null);
	}

	/**
	 * Gets the key from HSM.
	 *
	 * @param tepkLabel
	 * @return the tepk
	 * @throws KeyStoreException
	 * @throws UnrecoverableKeyException
	 * @throws NoSuchAlgorithmException
	 */
	public Key getTEPK( String tepkLabel) throws KeyStoreException, UnrecoverableKeyException, NoSuchAlgorithmException
	{
		return keyStore.getKey( tepkLabel, null);
	}
	// TEPK END.

	/**
	 *	Generate random symmetric key (base 64 encoded- equivalent to "openssl rand 32 -base64" - Oct SDK page A-7)
	 *
	 * @param numBits the num bits
	 * @return the byte[]
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchProviderException
	 */
	public final byte[] generateRSK(int numBits) throws NoSuchAlgorithmException, NoSuchProviderException {
		byte[] key = generateRSKRaw( numBits);

		byte[] chars = base64Encode(key);

		clean(key);
		return chars;
	}

	/**
	 * 	Generate raw random symmetric key
	 *
	 * @param numBits the num bits
	 * @return the byte[]
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchProviderException
	 */
	public final byte[] generateRSKRaw(int numBits) throws NoSuchAlgorithmException, NoSuchProviderException {
		SecureRandom sr = null;
		if(DEBUG)
			//TEST BC
			sr = SecureRandom.getInstance("SHA1PRNG");
		else
			sr = SecureRandom.getInstance("CRYPTOKI", keystore_provider);
		byte[] key = new byte[numBits/8];
		sr.nextBytes(key);

		return key;
	}

	/**
	 * Encrypt with TEPK
	 *
	 * @param keyToEncrypt the key to encrypt
	 * @param tepkLabel the tepk label
	 * @return the byte[]
	 * @throws IOException
	 * @throws GeneralSecurityException
	 */
	public byte [] encryptKeyHSM(byte[] keyToEncrypt, String tepkLabel) throws IOException, GeneralSecurityException{
		PublicKey publicKey = null;
		if(DEBUG)
			//TEST ONLY
			publicKey = rsaPair.getPublic();
		else
			publicKey = (RSAPubKey)keyStore.getKey(tepkLabel, null);

		byte[] encryptedKey = null;

		Cipher encCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding", keystore_provider);
		encCipher.init(Cipher.ENCRYPT_MODE, publicKey);
		encryptedKey = encCipher.doFinal(keyToEncrypt);

		return encryptedKey;
	}

	/**
	 * Decrypt with TEPK.
	 *
	 * @param encryptedRandomKey the encrypted random key
	 * @param tepkLabel the tepk label
	 * @return the byte[]
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchProviderException
	 * @throws NoSuchPaddingException
	 * @throws InvalidKeyException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	public byte[] decryptKeyHSM( byte[] encryptedRandomKey, String tepkLabel) throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{

		//TEST ONLY
		PrivateKey privateKey = rsaPair.getPrivate();

		byte[] plainRandomKey = null;
		Cipher encCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding", keystore_provider);

		encCipher.init(Cipher.DECRYPT_MODE, privateKey);
		plainRandomKey = encCipher.doFinal(encryptedRandomKey);
		return plainRandomKey;
	}

	//IV START

	/**
	 * Generate iv.
	 *
	 * @param numBits the num bits
	 * @return the byte[]
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchProviderException
	 */
	public byte[] generateIV (int numBits)throws NoSuchAlgorithmException, NoSuchProviderException {
		int numBytes = numBits/8;
		SecureRandom sr;
		if(DEBUG)
			sr = SecureRandom.getInstance("SHA1PRNG");
		else
			sr = SecureRandom.getInstance("CRYPTOKI", keystore_provider);
		byte[] key = new byte[numBytes];
		sr.nextBytes(key);

		return key;
	}

	/**
	 * Generate eiv.
	 *
	 * @param iv the iv
	 * @return the byte[]
	 */
	public final byte[] generateEIV(byte[] iv) {
		return urlSafeBase64Encode(iv);
	}
	//IV END

	/**
	 * Encrypt the payload / data using given key, salt and authentication data.
	 * For key encryption, additional authentication data is null.
	 * For data encryption in JWT, it's the header in json format.
	 *
	 * @param key the key
	 * @param salt the salt
	 * @param data the data
	 * @param aad the aad
	 * @return CipherTextData which contains the encrypted key and associated authentication tag information in base64 encoded format.
	 * @throws IllegalStateException
	 * @throws InvalidCipherTextException
	 */
	public final CipherTextData encryptData(final byte[] key, final byte[] salt, final byte[] data, final byte[] aad) throws IllegalStateException, InvalidCipherTextException {
		CipherTextData cipherTextData = null ;

		GCMBlockCipher gcm = new GCMBlockCipher(new AESFastEngine());
		gcm.init(ENCRYPT_MODE, new AEADParameters(new KeyParameter(key), AUTH_TAG_SIZE_BITS, salt, aad)); // no AAD for key encryption.
		int outsize = gcm.getOutputSize(data.length);
		byte[] out = new byte[outsize] ;
		int offOut = gcm.processBytes(data, 0, data.length, out, 0) ;
		gcm.doFinal(out, offOut);
		cipherTextData = getCipherTextData(out, AUTH_TAG_SIZE_BYTES);

		return cipherTextData ;
	}

	/**
	 * Encrypt the randomly generated CEK using shared secret (SHA2 hash) and salt (IV). It internally uses encryptData, which
	 * uses AES/GCM/256 bit key to encrypt data.
	 *
	 * @param secret the secret
	 * @param salt the salt
	 * @param keyToWrap the key to wrap
	 * @return CipherTextData which contains the encrypted key and associated authentication tag information in base64 encoded format.
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchProviderException
	 * @throws IllegalStateException
	 * @throws InvalidCipherTextException
	 */
	public final CipherTextData encryptKey(final String secret, final byte[] salt, final byte[] keyToWrap) throws NoSuchAlgorithmException, NoSuchProviderException, IllegalStateException, InvalidCipherTextException {
		CipherTextData cipherTextData = null ;

		byte[] kekBytes = getKekBytes(secret) ;
		cipherTextData = encryptData(kekBytes, salt, keyToWrap, null) ;
		return cipherTextData ;
	}


	/**
	 * Decrypt the encrypted key using shared secret (hash), salt and authentication tag.
	 *
	 * @param secret the secret
	 * @param salt the salt
	 * @param encryptedKey the encrypted key
	 * @param authTag the auth tag
	 * @return CEK in byte[] format.
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchProviderException
	 * @throws IllegalStateException
	 * @throws InvalidCipherTextException
	 */
	public final byte[] decryptKey(final String secret, final byte[] salt, final byte[] encryptedKey, final byte[] authTag ) throws NoSuchAlgorithmException, NoSuchProviderException, IllegalStateException, InvalidCipherTextException  {
		byte[] returnData ;

		byte[] ibkBytes = getKekBytes(secret) ;
		returnData = decryptData(ibkBytes, salt, encryptedKey, authTag, null) ;
		return returnData ;
	}

	/**
	 * Decrypt the encrypted data using CEK, salt and authentication tag.
	 * It also authenticates the auth tag to ensure encrypted data and associated authentication data is not tempered with.
	 *
	 * @param key the key
	 * @param salt the salt
	 * @param encrypted the encrypted
	 * @param authTag the auth tag
	 * @param aad the aad
	 * @return The decrypted data in byte[] format.
	 * @throws IllegalStateException
	 * @throws InvalidCipherTextException
	 */
	public final byte[] decryptData(final byte[] key, final byte[] salt, final byte[] encrypted, final byte[] authTag, final byte[] aad) throws IllegalStateException, InvalidCipherTextException {
		byte[] returnData = null ;
		GCMBlockCipher gcm = null;

		gcm = new GCMBlockCipher(new AESFastEngine());
		gcm.init(DECRYPT_MODE, new AEADParameters(new KeyParameter(key), AUTH_TAG_SIZE_BITS, salt, aad));
		byte[] finalData = new byte[encrypted.length+authTag.length] ;
		System.arraycopy(encrypted,0,finalData,0,encrypted.length);
		System.arraycopy(authTag,0,finalData, encrypted.length, authTag.length);
		int outSize =  gcm.getOutputSize(finalData.length) ;
		returnData = new byte[outSize] ;
		int offset = gcm.processBytes(finalData,0,finalData.length, returnData, 0);
		gcm.doFinal(returnData,offset) ;
		return returnData ;
	}

	/**
	 * Generate a 256 bit key based on shared secret to be used with AES algorithm.
	 *
	 * @param secret the secret
	 * @return the kek bytes
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchProviderException
	 */
	public byte[] getKekBytes(String secret) throws NoSuchAlgorithmException, NoSuchProviderException {
		// Secret could be of different length and may not be exactly 256 bits. hence getting SHA2 to use it as key.
		MessageDigest md = MessageDigest.getInstance("SHA-256", keystore_provider);
		md.update(secret.getBytes(UTF8));
		byte[] keyBytes = md.digest();
		assert keyBytes.length==32 ; // 32 byte == 256 bit size key
		return keyBytes ;
	}


	/** POC */

	public static PublicKeyData readCertificate(String fileName) throws IOException, CMSException, CertificateException, InvalidKeySpecException, NoSuchAlgorithmException {

		CertificateFactory certificateFactory = new CertificateFactory();
		X509Certificate certificate = (X509Certificate)certificateFactory.engineGenerateCertificate(new FileInputStream(fileName));

		//System.out.println("Cert:\n===================\n" + certificate.toString() + "\n");

		//public key
		PublicKey publicKey = certificate.getPublicKey();

		//fingerprint
		String fingerprint = DigestUtils.sha1Hex(certificate.getEncoded());

		PublicKeyData pkd = new PublicKeyData(publicKey, fingerprint);
		return pkd;
	}
	public static SecretKey genAESKey(int length) throws NoSuchAlgorithmException{
		KeyGenerator keyGen = KeyGenerator.getInstance("AES");
		keyGen.init(length);
		SecretKey secretKey = keyGen.generateKey();
		return secretKey;
	}

	public byte[] encryptCardInfoData(String cardInfo, SecretKey aesKey, byte []iv) throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, ShortBufferException{

		byte[] cardInfoBytes = cardInfo.getBytes();

		AlgorithmParameterSpec IVspec = new IvParameterSpec(iv);

		// encrypt with PKCS7 padding
		Cipher encrypterWithPad = Cipher.getInstance("AES/CBC/PKCS7PADDING", "BC");
		encrypterWithPad.init(Cipher.ENCRYPT_MODE, aesKey, IVspec);
		byte[] encryptedData = encrypterWithPad.doFinal(cardInfoBytes);

		return encryptedData;
	}

	public String decryptCardInfoData(byte[] encryptedData, SecretKey aesKey, byte []iv) throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, ShortBufferException{

		AlgorithmParameterSpec IVspec = new IvParameterSpec(iv);

		// decrypt with PKCS7 pad
		Cipher decrypterWithPad = Cipher.getInstance("AES/CBC/PKCS7PADDING", "BC");
		decrypterWithPad.init(Cipher.DECRYPT_MODE, aesKey, IVspec);
		byte[] buffer1 = new byte[encryptedData.length];
		int decryptLen1 = decrypterWithPad.doFinal(encryptedData, 0, encryptedData.length, buffer1);

		String decryptedData = new String(buffer1);
		return decryptedData;
	}


	private static String toHexString(byte[] bytes) {
		return javax.xml.bind.DatatypeConverter.printHexBinary(bytes);
	}
	/**POC END*/

	/**
	 * Clean.
	 *
	 * @param bytes the bytes
	 */
	//clean up memory
	private static void clean(byte[] bytes) {
		byte zero = 0;
		if (bytes != null)
			Arrays.fill(bytes, zero);
	}

	/**
	 * Url safe base64 encode.
	 *
	 * @param inputData the input data
	 * @return the byte[]
	 */
	public static final byte[] urlSafeBase64Encode(byte[] inputData) {
		//URL-safe encoder
		Base64 encoder = new Base64(1000, null, true);
		byte[] urlSafe = encoder.encode(inputData);
		return urlSafe;
	}

	/**
	 * Base64 encode.
	 *
	 * @param inputData the input data
	 * @return the byte[]
	 */
	public static final byte[] base64Encode(byte[] inputData) {
		Base64 encoder = new Base64(1000, null, false);
		byte[] base64 = encoder.encode(inputData);
		return base64;
	}

	/**
	 * Base64 decode.
	 *
	 * @param inputData the input data
	 * @return the byte[]
	 */
	//Decoder handles both url-safe and regular
	public static final byte[] base64Decode(String inputData) {
		Base64 encoder = new Base64();
		byte[] output = encoder.decode(inputData);
		return output;
	}


	/**
	 * Creates the CipherTextData object containing URL safe base64 encoded cipher text and authentication tag data.
	 *
	 * @param out the out
	 * @param authTagSize the auth tag size
	 * @return the cipher text data
	 */
	private static CipherTextData getCipherTextData(byte[] out, int authTagSize) {
		int ctSize = out.length - authTagSize ;
		byte[] cipherTextBytes = new byte[ctSize] ;
		byte[] mac = new byte[authTagSize] ;
		System.arraycopy(out,0, cipherTextBytes,0, ctSize) ;
		System.arraycopy(out, ctSize, mac, 0, authTagSize) ;
		CipherTextData cipherTextData = new CipherTextData(cipherTextBytes, mac) ;
		return cipherTextData;
	}


	/**
	 * Inner class to hold the Cipher Encryption operation result. Holds the cipher text and Auth tag details in URL safe Base64 encoded format.
	 */
	public static class CipherTextData {

		/** The cipher text. */
		private final String cipherText ;

		/** The auth tag. */
		private final String authTag ;

		/**
		 * Instantiates a new cipher text data.
		 *
		 * @param cipherOutput the cipher output
		 * @param macData the mac data
		 */
		public CipherTextData(final byte[] cipherOutput, final byte[] macData) {
			cipherText = new String(urlSafeBase64Encode(cipherOutput), UTF8);
			authTag    = new String(urlSafeBase64Encode(macData), UTF8);
		}

		/**
		 * Gets the cipher text.
		 *
		 * @return the cipher text
		 */
		public String getCipherText() {
			return cipherText ;
		}

		/**
		 * Gets the auth tag.
		 *
		 * @return the auth tag
		 */
		public String getAuthTag() {
			return authTag ;
		}

	}

	/**
	 * The Class JCESigner.
	 */
	private static class JCESigner implements ContentSigner {

		/** The Constant PKCS1_SHA256_WITH_RSA_OID. */
		private static final AlgorithmIdentifier PKCS1_SHA256_WITH_RSA_OID = new AlgorithmIdentifier(new ASN1ObjectIdentifier("1.2.840.113549.1.1.11"));

		/** The signature. */
		private Signature signature;

		/** The output stream. */
		private ByteArrayOutputStream outputStream;

		/**
		 * Instantiates a new JCE signer.
		 *
		 * @param privateKey the private key
		 * @param signatureAlgorithm the signature algorithm
		 */
		public JCESigner(PrivateKey privateKey, String signatureAlgorithm) {
			//			if (!"SHA256withRSA".equals(signatureAlgorithm)) {
			//				throw new IllegalArgumentException("Signature algorithm \"" + signatureAlgorithm + "\" not yet supported");
			//			}
			try {
				this.outputStream = new ByteArrayOutputStream();
				this.signature = Signature.getInstance(signatureAlgorithm);
				this.signature.initSign(privateKey);
			} catch (GeneralSecurityException gse) {
				throw new IllegalArgumentException(gse.getMessage());
			}
		}

		/* (non-Javadoc)
		 * @see org.bouncycastle.operator.ContentSigner#getAlgorithmIdentifier()
		 */
		@Override
		public AlgorithmIdentifier getAlgorithmIdentifier() {
			if (signature.getAlgorithm().equals("SHA256withRSA")) {
				return PKCS1_SHA256_WITH_RSA_OID;
			} else {
				return null;
			}
		}

		/* (non-Javadoc)
		 * @see org.bouncycastle.operator.ContentSigner#getOutputStream()
		 */
		@Override
		public OutputStream getOutputStream() {
			return outputStream;
		}

		/* (non-Javadoc)
		 * @see org.bouncycastle.operator.ContentSigner#getSignature()
		 */
		@Override
		public byte[] getSignature() {
			try {
				signature.update(outputStream.toByteArray());
				return signature.sign();
			} catch (GeneralSecurityException gse) {
				gse.printStackTrace();
				return null;
			}
		}
	}


	/**
	 * Inner class to hold public key info (pk and fingerprint).
	 */
	public static class PublicKeyData {

		private final PublicKey pk;

		private final String fingerprint;

		public PublicKeyData(final PublicKey pk, final String fingerprint) {
			this.pk = pk;
			this.fingerprint = fingerprint;
		}

		public PublicKey getPublicKey() {
			return pk;
		}

		public String getFingerprint() {
			return fingerprint;
		}

	}
}