package ca.ugo.mobilewallet.token.encryptionutil;

import java.io.IOException;
import java.nio.charset.Charset;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.ShortBufferException;

import org.apache.log4j.Logger;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.crypto.InvalidCipherTextException;

import ca.ugo.mobilewallet.token.encryptionutil.EncryptionUtil.PublicKeyData;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * The Class JWTUtil.
 */
public final class JWTUtil {

	private static final Charset UTF8 = Charset.forName("UTF-8");
	static Logger log = Logger.getLogger("JWTUtil");

	/** Mapper for JSON serialization. */
	private static ObjectMapper mapper = new ObjectMapper().configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false);

	/** The tepk label. */
	private final String TEPK_LABEL;

	/** The encryption util instance. */
	private final EncryptionUtil encryptionUtil;


	/**
	 * Default JWT util constructor (using HSM).
	 *
	 * @param keystore_provider the keystore_provider
	 * @param slotPassword the slot password
	 * @param keystore_type the keystore_type
	 * @param TEPK_LABEL the tepk label
	 * @throws KeyStoreException
	 * @throws NoSuchProviderException
	 * @throws NoSuchAlgorithmException
	 * @throws CertificateException
	 * @throws IOException
	 * @throws InvalidKeyException
	 * @throws UnrecoverableKeyException
	 * @throws NoSuchPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	public JWTUtil(String keystore_provider, String slotPassword, String keystore_type, String TEPK_LABEL) throws InvalidKeyException, KeyStoreException, NoSuchProviderException, NoSuchAlgorithmException, CertificateException, UnrecoverableKeyException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, IOException{
		this(keystore_provider, slotPassword, keystore_type, TEPK_LABEL, false);
	}

	/**
	 * Configurable JWT util constructor
	 *
	 * @param keystore_provider
	 * @param slotPassword
	 * @param keystore_type
	 * @param TEPK_LABEL
	 * @param debug - see DEBUG in main class
	 * @throws KeyStoreException
	 * @throws NoSuchProviderException
	 * @throws NoSuchAlgorithmException
	 * @throws CertificateException
	 * @throws IOException
	 * @throws InvalidKeyException
	 * @throws UnrecoverableKeyException
	 * @throws NoSuchPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	public JWTUtil(String keystore_provider, String slotPassword, String keystore_type, String TEPK_LABEL, boolean debug) throws KeyStoreException, NoSuchProviderException, NoSuchAlgorithmException, CertificateException, IOException, InvalidKeyException, UnrecoverableKeyException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException{
		this.TEPK_LABEL =  TEPK_LABEL;
		this.encryptionUtil = new EncryptionUtil(keystore_provider, slotPassword, keystore_type, debug);
	}

	///
	///JWE FOR KEY ENCRYPTION
	///
	/**
	 * Creates JWE for a key.
	 * If key is null, a new random symmetric key will be generated
	 *
	 * @param plainText the plain text
	 * @param encryptionKey the encryption key
	 * @param kid the kid
	 * @return the JWE
	 * @throws IllegalStateException
	 * @throws InvalidCipherTextException
	 * @throws IOException
	 * @throws GeneralSecurityException
	 */
	public final String createJweKey(byte[] plainText, byte[] encryptionKey, String kid) throws IOException, GeneralSecurityException, IllegalStateException, InvalidCipherTextException{
		String jwe = null;
		byte[] rsk;
		if(encryptionKey == null)
			rsk = encryptionUtil.generateRSKRaw(EncryptionUtil.CEK_SIZE_BITS);
		else
			rsk = EncryptionUtil.base64Decode(new String(encryptionKey));

		log.info("DSK IN: "+ new String(plainText, UTF8));
		log.info("RSK IN: "+ new String(rsk, UTF8));

		//Encrypt RSK using TEPK
		byte [] encryptedRSK = encryptKey(rsk);

		byte[] iv = encryptionUtil.generateIV(EncryptionUtil.IV_SIZE_BITS);

		EncryptionUtil.CipherTextData encryptedData = encryptionUtil.encryptData(rsk, iv, plainText, null);//null for key encryption

		byte[] encodedHeaderBytes = buildJWEEncodedHeaderBytes(kid, iv, encryptedData);

		jwe = buildJwe(encodedHeaderBytes, encryptedRSK, iv, encryptedData);
		return jwe;
	}

	/**
	 * Creates JWE for a given key.
	 *
	 * @param plainText the plain text
	 * @param kid the kid
	 * @return the string
	 * @throws IllegalStateException
	 * @throws InvalidCipherTextException
	 * @throws IOException
	 * @throws GeneralSecurityException
	 */
	public final String createJweKey(byte[] plainText, String kid) throws IllegalStateException, InvalidCipherTextException, IOException, GeneralSecurityException {
		return createJweKey(plainText, null, kid);
	}

	/**
	 * Decrypt jwe key object.
	 * For testing only, normally we don't have the private key needed to decrypt
	 *
	 * @param jwe string
	 * @return the key string
	 * @throws IllegalStateException
	 * @throws InvalidCipherTextException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchProviderException
	 * @throws InvalidKeyException
	 * @throws NoSuchPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	public final String decryptJweKey( JWEData jwe) throws IllegalStateException, InvalidCipherTextException, InvalidKeyException, NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException  {
		byte[] data;
		byte[] cekBytes = encryptionUtil.decryptKeyHSM( EncryptionUtil.base64Decode(jwe.getCek()), TEPK_LABEL);
		log.info("RSK OUT: "+ new String(cekBytes, UTF8));

		log.info("HEADER OUT: "+ new String(EncryptionUtil.base64Decode(jwe.getHeaderJsonEncoded()), UTF8));

		data = encryptionUtil.decryptData(
				cekBytes,
				EncryptionUtil.base64Decode(jwe.getDataSalt()),
				EncryptionUtil.base64Decode(jwe.getCipherText()),
				EncryptionUtil.base64Decode(jwe.getDataAuthTag()),
				null);

		log.info("DSK OUT: "+ new String(data, UTF8));
		return new String(data, UTF8);
	}

	/**
	 * Decrypt JWE for key string.
	 * For testing only, normally we don't have the private key needed to decrypt
	 *
	 * @param encryptedJwe the encrypted jwe
	 * @return the key
	 * @throws IllegalStateException
	 * @throws InvalidCipherTextException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchProviderException
	 * @throws InvalidKeyException
	 * @throws NoSuchPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	//For testing only, normally we don't have the private key needed to decrypt
	public final String decryptJweKey(String encryptedJwe) throws IllegalStateException, InvalidCipherTextException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
		return decryptJweKey(new JWEData(encryptedJwe));
	}


	///
	///JWE FOR PEM, signing
	///
	/**
	 * Generate key pair.
	 *
	 * @return the key pair
	 * @throws InvalidKeyException
	 * @throws UnrecoverableKeyException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchProviderException
	 * @throws NoSuchPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 * @throws KeyStoreException
	 */
	public final KeyPair generateKeyPair() throws InvalidKeyException, UnrecoverableKeyException, NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, KeyStoreException{
		return encryptionUtil.createKeyPair();
	}

	/**
	 * Gets the private key exponent.
	 *
	 * @param pk the pk
	 * @return the private key exponent
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeySpecException the invalid key spec exception
	 * @throws NoSuchProviderException
	 */
	public String getPrivateKeyExponent(PrivateKey pk) throws NoSuchAlgorithmException, InvalidKeySpecException, NoSuchProviderException{
		return encryptionUtil.getPrivateKeyExponent(pk);
	}

	/**
	 * Gets the signing certificate.
	 *
	 * @param keyPair the key pair
	 * @return the signing certificate
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeySpecException the invalid key spec exception
	 * @throws CertificateException the certificate exception
	 * @throws IOException
	 */
	public Certificate getSigningCertificate(KeyPair keyPair) throws NoSuchAlgorithmException, InvalidKeySpecException, CertificateException, IOException{
		return encryptionUtil.getSigningCertificate(keyPair);
	}

	/**
	 * Gets the certificate by name.
	 *
	 * @param certName the cert name
	 * @return the certificate by name
	 * @throws KeyStoreException
	 */
	//Extract certificate
	public Certificate getCertificateByName(String certName) throws KeyStoreException{
		return encryptionUtil.getCertificateByName(certName);
	}

	/**
	 * Certificate to pem
	 *
	 * @param cert the certificate
	 * @return the string
	 * @throws IOException
	 */
	public static String toPEM(Certificate cert) throws IOException {
		return EncryptionUtil.toPEM(cert);
	}

	/**POC START*/
	public byte[] generateIV (int numBits)throws NoSuchAlgorithmException, NoSuchProviderException {
		return encryptionUtil.generateIV(numBits);
	}
	public PublicKeyData readCertificate(String fileName) throws IOException, CMSException, CertificateException, InvalidKeySpecException, NoSuchAlgorithmException {
		return EncryptionUtil.readCertificate(fileName);
	}
	public SecretKey genAESKey(int length) throws NoSuchAlgorithmException{
		return EncryptionUtil.genAESKey(length);
	}
	public byte[] encryptCardInfoData(String cardInfo, SecretKey aesKey, byte [] iv) throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException, NoSuchPaddingException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, ShortBufferException{
		return encryptionUtil.encryptCardInfoData(cardInfo, aesKey, iv);
	}
	public String decryptCardInfoData(byte[] encryptedData, SecretKey aesKey, byte [] iv) throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException, NoSuchPaddingException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, ShortBufferException{
		return encryptionUtil.decryptCardInfoData(encryptedData, aesKey, iv);
	}
	/**POC END*/

	///
	///JWS
	///
	/**
	 * Creates the assertion.
	 *
	 * @param kid
	 * @param jti
	 * @param assertion
	 * @param secret
	 * @return assertionToken
	 * @throws JsonProcessingException
	 * @throws InvalidKeyException
	 * @throws NoSuchAlgorithmException
	 */
	public String createAssertion( String kid, String jti, String assertion, String secret) throws JsonProcessingException, InvalidKeyException, NoSuchAlgorithmException {
		byte[] encodedHeaderStr = buildJWSEncodedHeaderBytes(kid, jti);
		StringBuilder stringToSign = new StringBuilder(new String(encodedHeaderStr));
		stringToSign.append('.');
		stringToSign.append(EncryptionUtil.urlSafeBase64Encode(assertion.getBytes(UTF8)));

		String signature = encryptionUtil.computeHmacSHA256(secret, stringToSign.toString());
		stringToSign.append(".");
		stringToSign.append(signature);
		String assertionToken = stringToSign.toString();
		return assertionToken;
	}

	///
	///JWT HEADER functions
	///
	/**
	 * Gets the json.
	 *
	 * @param header
	 * @return json string
	 * @throws JsonProcessingException
	 */
	private static String getJson(JWEHeader header) throws JsonProcessingException {
		String json = mapper.writeValueAsString(header);
		return json;
	}

	/**
	 * Builds the jws encoded header bytes.
	 *
	 * @param kid
	 * @param jti
	 * @return url safe header
	 * @throws JsonProcessingException
	 */
	private byte[] buildJWSEncodedHeaderBytes(String kid, String jti) throws JsonProcessingException{
		JWEHeader header = new JWEHeader();
		header.setKid(kid);
		header.setIat( String.valueOf( System.currentTimeMillis()));
		header.setJti(jti);
		header.setAlg("HS256");
		header.setTyp("JWT");

		String headerJson = getJson(header);

		return EncryptionUtil.urlSafeBase64Encode( headerJson.getBytes(UTF8));

	}

	/**
	 * Builds the jwe encoded header bytes.
	 *
	 * @param kid
	 * @param keySalt
	 * @param keyWrapped
	 * @return the byte[]
	 * @throws JsonProcessingException
	 */
	private static byte[] buildJWEEncodedHeaderBytes(String kid, byte[] keySalt, EncryptionUtil.CipherTextData keyWrapped) throws JsonProcessingException {
		JWEHeader header = new JWEHeader();
		header.setKid(kid);
		header.setIv(new String(EncryptionUtil.urlSafeBase64Encode(keySalt), UTF8));
		header.setTag(keyWrapped.getAuthTag());
		header.setIat( String.valueOf( System.currentTimeMillis()));
		header.setAlg("RSA1_5");
		header.setEnc("AGCM256");
		header.setTyp("JOSE");
		header.setChannelSecurityContext("RSA_PKI");

		String headerJson = getJson(header);

		return EncryptionUtil.urlSafeBase64Encode( headerJson.getBytes(UTF8));
	}

	/**
	 * Builds the jwe.
	 *
	 * @param encodedHeader
	 * @param keyWrapped
	 * @param dataSalt
	 * @param encryptedData
	 * @return the JWE string
	 */
	private static String buildJwe(byte[] encodedHeader,
			byte[] keyWrapped,
			byte[] dataSalt,
			EncryptionUtil.CipherTextData encryptedData) {

		String eIV = new String(EncryptionUtil.urlSafeBase64Encode(dataSalt), UTF8);
		String eTag = encryptedData.getAuthTag();

		StringBuilder jwe = new StringBuilder();

		jwe.append(new String(encodedHeader, UTF8)).append(".")
		.append(new String(EncryptionUtil.urlSafeBase64Encode(keyWrapped), UTF8)).append(".")
		.append(eIV).append(".")
		.append(encryptedData.getCipherText()).append(".")
		.append(eTag);

		return jwe.toString();
	}

	/**
	 * Generate dsk.
	 *
	 * @return RSK byte[]
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchProviderException
	 */
	//KEYS
	public byte [] generateDSK() throws NoSuchAlgorithmException, NoSuchProviderException{
		return encryptionUtil.generateRSK(256); //32 bytes
	}

	/**
	 * Encrypt key.
	 *
	 * @param dsk
	 * @return encrypted dsk
	 * @throws IOException
	 * @throws GeneralSecurityException
	 */
	public byte[] encryptKey(byte[] dsk) throws IOException, GeneralSecurityException{
		//Encrypt DSK using TEPK
		return encryptionUtil.encryptKeyHSM(dsk, TEPK_LABEL);
	}

	/**
	 * The Class JWEData.
	 */
	public static class JWEData {

		/** The header json encoded. */
		private String headerJsonEncoded;

		/** The header. */
		private JWTUtil.JWEHeader header;

		/** The cek. */
		private String cek;

		/** The data salt. */
		private String dataSalt;

		/** The cipher text. */
		private String cipherText;

		/** The data auth tag. */
		private String dataAuthTag;

		/**
		 * Instantiates a new JWE data object (parse JWE string).
		 *
		 * @param encryptedJwe the encrypted jwe
		 */
		public JWEData(String encryptedJwe) {

			assert (encryptedJwe != null);
			try {
				String[] parts = encryptedJwe.split("\\.", -1);
				this.headerJsonEncoded = parts[0];
				this.cek = parts[1];
				this.dataSalt = parts[2];
				this.cipherText = parts[3];
				this.dataAuthTag = parts[4];
				byte[] hdBytes = EncryptionUtil.base64Decode(this.headerJsonEncoded);

				this.header = (JWTUtil.mapper.readValue( hdBytes, JWTUtil.JWEHeader.class));
			} catch (Exception ex) {
				System.out.println("Error parsing jwe into sub-parts, jwe:" + encryptedJwe);
				System.out.println(ex.getMessage());
				throw new RuntimeException(ex);
			}
		}

		/**
		 * Gets the header.
		 *
		 * @return the header
		 */
		public JWTUtil.JWEHeader getHeader() {
			return this.header;
		}

		/**
		 * Gets the header json encoded.
		 *
		 * @return the header json encoded
		 */
		public String getHeaderJsonEncoded() {
			return this.headerJsonEncoded;
		}

		/**
		 * Gets the header json bytes.
		 *
		 * @return the header json bytes
		 */
		public byte[] getHeaderJsonBytes() {
			return EncryptionUtil.base64Decode(this.headerJsonEncoded);
		}

		/**
		 * Gets the cek.
		 *
		 * @return the cek
		 */
		public String getCek() {
			return this.cek;
		}

		/**
		 * Gets the data salt.
		 *
		 * @return the data salt
		 */
		public String getDataSalt() {
			return this.dataSalt;
		}

		/**
		 * Gets the cipher text.
		 *
		 * @return the cipher text
		 */
		public String getCipherText() {
			return this.cipherText;
		}

		/**
		 * Gets the data auth tag.
		 *
		 * @return the data auth tag
		 */
		public String getDataAuthTag() {
			return this.dataAuthTag;
		}
	}


	/**
	 * The Class JWSData.
	 */
	public static class JWSData {

		/** The header json encoded. */
		private String headerJsonEncoded;

		/** The header. */
		private JWTUtil.JWEHeader header;

		/**
		 * Instantiates a new JWS data object (parse JWS string).
		 *
		 * @param encryptedJwe the encrypted jwe
		 */
		public JWSData(String encryptedJwe) {

			assert (encryptedJwe != null);
			try {
				String[] parts = encryptedJwe.split("\\.", -1);
				this.headerJsonEncoded = parts[0];
				byte[] hdBytes = EncryptionUtil.base64Decode(this.headerJsonEncoded);

				this.header = (JWTUtil.mapper.readValue( hdBytes, JWTUtil.JWEHeader.class));
			} catch (Exception ex) {
				System.out.println("Error parsing jwe into sub-parts, jwe:" + encryptedJwe);
				System.out.println(ex.getMessage());
				throw new RuntimeException(ex);
			}
		}

		/**
		 * Gets the header.
		 *
		 * @return the header
		 */
		public JWTUtil.JWEHeader getHeader() {
			return this.header;
		}

		/**
		 * Gets the header json encoded.
		 *
		 * @return the header json encoded
		 */
		public String getHeaderJsonEncoded() {
			return this.headerJsonEncoded;
		}

		/**
		 * Gets the header json bytes.
		 *
		 * @return the header json bytes
		 */
		public byte[] getHeaderJsonBytes() {
			return EncryptionUtil.base64Decode(this.headerJsonEncoded);
		}
	}

	/**
	 * The Class JWEHeader.
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public static class JWEHeader {

		/** The alg. */
		private String alg;

		/** The iv. */
		private String iv;

		/** The tag. */
		private String tag;

		/** The enc. */
		private String enc;

		/** The typ. */
		private String typ;

		/** The kid. */
		private String kid;

		/** The jti. */
		private String jti;

		/** The iat. */
		private String iat;

		/** The channel security context. */
		private String channelSecurityContext;

		/**
		 * Gets the alg.
		 *
		 * @return the alg
		 */
		public String getAlg() {
			return this.alg;
		}

		/**
		 * Gets the iv.
		 *
		 * @return the iv
		 */
		public String getIv() {
			return this.iv;
		}

		/**
		 * Gets the tag.
		 *
		 * @return the tag
		 */
		public String getTag() {
			return this.tag;
		}

		/**
		 * Gets the enc.
		 *
		 * @return the enc
		 */
		public String getEnc() {
			return this.enc;
		}

		/**
		 * Gets the typ.
		 *
		 * @return the typ
		 */
		public String getTyp() {
			return this.typ;
		}

		/**
		 * Gets the kid.
		 *
		 * @return the kid
		 */
		public String getKid() {
			return this.kid;
		}

		/**
		 * Gets the iat.
		 *
		 * @return the iat
		 */
		public String getIat() {
			return this.iat;
		}

		/**
		 * Sets the typ.
		 *
		 * @param string the new typ
		 */
		public void setTyp(String string) {
			typ = string;
		}

		/**
		 * Sets the enc.
		 *
		 * @param string the new enc
		 */
		public void setEnc(String string) {
			enc = string;
		}

		/**
		 * Sets the alg.
		 *
		 * @param string the new alg
		 */
		public void setAlg(String string) {
			alg = string;
		}

		/**
		 * Sets the kid.
		 *
		 * @param kid the new kid
		 */
		public void setKid(String kid) {
			this.kid = kid;
		}

		/**
		 * Sets the iv.
		 *
		 * @param salt the new iv
		 */
		public void setIv(String salt) {
			this.iv = salt;
		}

		/**
		 * Sets the tag.
		 *
		 * @param tag the new tag
		 */
		public void setTag(String tag) {
			this.tag = tag;
		}

		/**
		 * Sets the iat.
		 *
		 * @param iat the new iat
		 */
		public void setIat(String iat) {
			this.iat = iat;
		}

		/**
		 * Gets the channel security context.
		 *
		 * @return the channel security context
		 */
		public String getChannelSecurityContext() {
			return channelSecurityContext;
		}

		/**
		 * Sets the channel security context.
		 *
		 * @param channelSecurityContext the new channel security context
		 */
		public void setChannelSecurityContext(String channelSecurityContext) {
			this.channelSecurityContext = channelSecurityContext;
		}

		/**
		 * Gets the jti.
		 *
		 * @return the jti
		 */
		public String getJti() {
			return jti;
		}

		/**
		 * Sets the jti.
		 *
		 * @param jti the new jti
		 */
		public void setJti(String jti) {
			this.jti = jti;
		}
	}

}
