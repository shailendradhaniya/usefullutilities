import java.io.IOException;
import java.io.InputStream;
import java.security.PublicKey;
import java.util.Properties;

import javax.crypto.SecretKey;

import org.apache.log4j.Logger;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.crypto.AsymmetricBlockCipher;
import org.bouncycastle.crypto.digests.SHA256Digest;
import org.bouncycastle.crypto.encodings.OAEPEncoding;
import org.bouncycastle.crypto.engines.RSAEngine;
import org.bouncycastle.crypto.params.AsymmetricKeyParameter;
import org.bouncycastle.crypto.util.PublicKeyFactory;

import ca.ugo.mobilewallet.token.encryptionutil.EncryptionUtil.PublicKeyData;
import ca.ugo.mobilewallet.token.encryptionutil.JWTUtil;

public class MCTokenization {

	public static String keystore_provider;

	public static String slotPassword;

	public static String keystore_type;

	static Logger log = Logger.getLogger("TestJWT");


	public static void main(String[] args) {

		String certFileName = "c://72316//72316.crt";
		String cardInfo = "{ \"accountNumber\" : \"5186170810000006\", \"expiryMonth\" : \"12\" , \"expiryYear\" : \"18\" , \"source\" : \"CARD_ON_FILE\"}";

		cardDataEncrypt( certFileName, cardInfo);

	}

	public static void cardDataEncrypt(String fileName, String cardInfo) {
		try{

			init();

			keystore_provider = "BC";
			JWTUtil jwtUtil = new JWTUtil(keystore_provider, slotPassword, keystore_type, null, true);

			PublicKeyData pkd = jwtUtil.readCertificate(fileName);

			PublicKey mcPublicKey = pkd.getPublicKey();
			String fingerprint = pkd.getFingerprint();

			SecretKey aesKey = jwtUtil.genAESKey(128);

			//encrypt AES key with MC key
			SubjectPublicKeyInfo publicKeyInfo = new SubjectPublicKeyInfo(ASN1Sequence.getInstance(mcPublicKey.getEncoded()));

			AsymmetricKeyParameter param = PublicKeyFactory.createKey(publicKeyInfo);
			SHA256Digest sha = new SHA256Digest();

			AsymmetricBlockCipher cipher = new OAEPEncoding( new RSAEngine(), sha);
			cipher.init(true, param);

			byte[] encryptedAES = cipher.processBlock(aesKey.getEncoded(), 0, 16);


			//encrypt input data
			byte[] iv = jwtUtil.generateIV( 128);
			byte[] encryptedData = jwtUtil.encryptCardInfoData( cardInfo, aesKey, iv);
			String decryptedData = jwtUtil.decryptCardInfoData( encryptedData, aesKey, iv);

			System.out.println("======================VALUES==================================");
			System.out.println("IV: " + toHexString(iv));
			System.out.println("========================================================");
			System.out.println("Cert fingerprint: " + fingerprint);
			System.out.println("========================================================");
			System.out.println("Unencrypted Key: " + toHexString(aesKey.getEncoded()));
			System.out.println("========================================================");
			System.out.println("Encrypted Key:   " + toHexString(encryptedAES));
			System.out.println("========================================================");
			System.out.println("Encrypted Data: " + toHexString(encryptedData));
			System.out.println("========================================================");
			System.out.println("");
			System.out.println("========================INPUT/OUTPUT TEST================================");
			System.out.println("Input Data:     " + decryptedData);
			System.out.println("Decrypted Data: " + decryptedData);
			System.out.println("========================================================");

			log.info("Done");

		} catch(Exception ex){
			System.out.println("Error: "+ ex.getMessage());
			ex.printStackTrace();
		}
	}



	private static void init(){
		Properties prop = new Properties();
		InputStream input = null;

		try {

			String filename = "config.properties";
			input = MCTokenization.class.getClassLoader().getResourceAsStream(filename);
			if(input==null){
				System.out.println("Sorry, unable to find " + filename);
				return;
			}

			//load a properties file from class path, inside static method
			prop.load(input);

			//get the property value and print it out
			keystore_provider = prop.getProperty("keystore_provider");
			slotPassword = prop.getProperty("slotPassword");
			keystore_type = prop.getProperty("keystore_type");

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally{
			if(input!=null){
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

	private static String toHexString(byte[] bytes) {
		return javax.xml.bind.DatatypeConverter.printHexBinary(bytes);
	}

}
